export interface TicketFilter {
  assigneeId: number;
  completed: boolean;
}
