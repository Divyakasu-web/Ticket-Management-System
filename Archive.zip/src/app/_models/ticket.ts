export interface Ticket {
  id: number;
  description: string;
  assigneeId: number;
  completed: boolean;
}
