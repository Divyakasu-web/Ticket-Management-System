export interface TicketWithUser {
  id: number;
  description: string;
  assigneeName: string;
  completed: boolean;
}
