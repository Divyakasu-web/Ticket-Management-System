# ticket-system

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/ticket-system)
